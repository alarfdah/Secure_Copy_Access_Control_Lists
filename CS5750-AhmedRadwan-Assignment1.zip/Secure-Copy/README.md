Date: 02/04/2019
Class: CS5750
Assignment: Assignment 1
Author: Ahmed Radwan

2 accounts:
  Owner: Should have a "getbin" and a "files" folder in the home directory
  User: Should copy to his own home directory
